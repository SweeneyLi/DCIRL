import os
import numpy as np
import cv2
from visdom import Visdom
import pdb
import torch
import torch.nn as nn

class Visualization(object):
  def __init__(self, opt):
    self.viz = Visdom(port=7559, server='http://localhost', base_url='/', username='',password='', use_incoming_socket=True, env=opt.visual_env)
    assert self.viz.check_connection(timeout_seconds=3), 'Please Open The Visdom Server'

    self.nrow = opt.visual_nrow
    self.scale = opt.visual_scale
    self.batch_size = opt.batch_size
    self.height = opt.height
    self.width = opt.width
    
    self.sample_win = self.viz.images(np.zeros((self.batch_size, 3, self.height/self.scale, self.width/self.scale)),nrow = self.nrow, opts={'title':'Samples Domain'})
    self.train_loss_win = self.viz.line(
            X=np.column_stack(([0],[0],[0])),
            Y=np.column_stack(([0],[0],[0])),
            opts={'title':'train curve',
                  'xlabel':'iteration',
                  'ylabel':'loss',
                  'legend':['loss', 'cls_loss', 'triplet_loss'],
                  'width':1024,
                  'height':256,
                  'showlegend':True})
    self.downsample = nn.Upsample(scale_factor=1./self.scale, mode='bilinear', align_corners=True)

  def run(self, samples, loss, cls_loss, triplet_loss, cnt):
    loss = [np.array(loss)]
    self.viz.line(X=np.column_stack(([cnt], [cnt], [cnt])),
                  Y=np.column_stack((loss, cls_loss, triplet_loss)),
                  win=self.train_loss_win,
                  update='append')
    post_samples = self.post_processing(samples)
    self.viz.images(post_samples.numpy(),
                    nrow=self.nrow,
                    win=self.sample_win,
                    opts={'title':'Samples Domain'})
  def post_processing(self, image):
    channel = image.shape[0]
    if channel == 1:
      image.repeat(1, 3, 1, 1)
    image = image*255
    image = self.downsample(image)
    return image
