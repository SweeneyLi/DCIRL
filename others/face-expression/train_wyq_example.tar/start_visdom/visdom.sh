nohup python -m visdom.server -p 7559 &
